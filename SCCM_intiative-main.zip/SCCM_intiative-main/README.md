if you see, you see not. if you know you know not. 
while I may not be equipped, my strength has never faded. as your approach nears the bond is refurbished, signaling the content.
